$(".overlap").click(function(){
    alert("사용 가능!(임시)")
});