$('.service-submenu a').click(function(){
        $('.service-submenu a').removeClass("on");
        $(this).addClass("on");
});

$('.pagination .num').click(function(){
        $('.pagination .num').removeClass("action");
        $(this).addClass("action");
    });
    